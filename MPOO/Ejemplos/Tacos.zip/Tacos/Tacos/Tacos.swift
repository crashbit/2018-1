//
//  Tacos.swift
//  Tacos
//
//  Created by Germán Santos Jaimes on 11/11/17.
//  Copyright © 2017 ioslab. All rights reserved.
//

import Foundation

struct Taco{
    var titulo:String
    var descripcion:String
    var precio: Double
}
