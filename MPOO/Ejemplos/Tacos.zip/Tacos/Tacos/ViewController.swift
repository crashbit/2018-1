//
//  ViewController.swift
//  Tacos
//
//  Created by Germán Santos Jaimes on 11/11/17.
//  Copyright © 2017 ioslab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Declaramos un arreglo que maneje nuestro menu de tacos
    var tacos:[Taco] = []
    
   
    // Esta funcion es como el MAIN en C
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        //Creamos unos cuantos tacos
        
        let tacoMaciza = Taco(titulo: "Maciza", descripcion: "Rico taco de maciza de puerco", precio: 15.0)
        let tacoCarnitas = Taco(titulo: "Carnitas", descripcion: "Carnitas al estilo michoacan", precio: 12.0)
        let tacoSuadero = Taco(titulo: "Suadero", descripcion: "Suadero solo de la CDMX", precio: 10.0)
        let tacoBistek = Taco(titulo: "Bistek", descripcion: "Carne 100% Sonora", precio: 20.0)
        let tacoPastor = Taco(titulo: "Pastor", descripcion: "Se que de esos tacos nada nos faltara", precio: 25.0)
        
        // Ahora los metemos al arreglo que aparecera en la tabla
        tacos = [tacoMaciza, tacoSuadero, tacoBistek, tacoPastor, tacoCarnitas]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // Trabajamos con los protocolos para el Datasource
    
    //Esta funcion nos devuelve cuantas celdas vamos a pintar en la tabla
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Regresamos cuantos tacos tenemos
        return tacos.count
    }
    
    
    // Esta funcion pinta cada celda que aparecera en la tabla
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Ahora llenamos cada celda de la tabla
        
        //Creamos un identificador para la Celda, de tal forma que UITableView lo reconozca
        let celdaIdentificador = "TacoCell"
        
        // Creamos celdas a partir de ser reusables, indicamos a que celda, una vez que tenemos la celda le decimos de que tipo es, si falla que nos convierta
        // la celda en lo mas sencillo
        guard let cell = tableView.dequeueReusableCell(withIdentifier: celdaIdentificador, for: indexPath) as? TacoCell else {return UITableViewCell()}
        
        // Ya que creamos la celda ahora le llenamos los campos
        cell.nombre.text = tacos[indexPath.row].titulo
        cell.desc.text = tacos[indexPath.row].descripcion
        
        // Debido a que precio del tipo Double lo casteamos para que sea String
        let precio = String(tacos[indexPath.row].precio)
        cell.precio.text = precio
        
        // Regresamos la celda para que aparezca en la tabla.
        return cell
    }

}

