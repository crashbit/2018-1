//
//  TacoCell.swift
//  Tacos
//
//  Created by Germán Santos Jaimes on 11/11/17.
//  Copyright © 2017 ioslab. All rights reserved.
//

import UIKit

class TacoCell: UITableViewCell{
    
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var precio: UILabel!

}
